import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeRequestSchema, type AnalyzeRequest, type AnalyzeResponse } from "@shared/schema";
import { analyzeClickbait } from "./lib/openai";
import { scrapeUrl } from "./lib/scraper";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Analyze content endpoint
  app.post("/api/analyze", async (req, res) => {
    try {
      // Validate request body
      const parseResult = analyzeRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid request data",
          errors: parseResult.error.errors 
        });
      }

      const { type, content }: AnalyzeRequest = parseResult.data;
      const startTime = Date.now();

      let textToAnalyze = content;
      let title: string | undefined;
      let originalText: string | undefined;

      // If analyzing URL, scrape the content first
      if (type === "url") {
        try {
          const scrapedContent = await scrapeUrl(content);
          textToAnalyze = scrapedContent.text;
          title = scrapedContent.title;
          originalText = scrapedContent.text;
        } catch (error) {
          return res.status(400).json({ 
            message: `Failed to scrape URL: ${error.message}` 
          });
        }
      }

      // Validate content length
      if (textToAnalyze.length < 10) {
        return res.status(400).json({ 
          message: "Content is too short for meaningful analysis. Please provide at least 10 characters." 
        });
      }

      if (textToAnalyze.length > 10000) {
        textToAnalyze = textToAnalyze.substring(0, 10000) + '...';
      }

      // Analyze with OpenAI
      let analysis;
      try {
        analysis = await analyzeClickbait(textToAnalyze, title);
      } catch (error) {
        return res.status(500).json({ 
          message: `AI analysis failed: ${error.message}` 
        });
      }

      const processingTime = Date.now() - startTime;

      // Determine classification based on score
      let classification = "Low Risk";
      if (analysis.clickbaitScore >= 70) {
        classification = "High Risk";
      } else if (analysis.clickbaitScore >= 40) {
        classification = "Medium Risk";
      }

      // Store analysis in database
      const storedAnalysis = await storage.createAnalysis({
        type,
        content,
        originalText,
        title,
        clickbaitScore: analysis.clickbaitScore,
        classification,
        summary: analysis.summary,
        indicators: analysis.indicators || [],
        confidence: analysis.confidence,
        processingTime
      });

      const response: AnalyzeResponse = {
        id: storedAnalysis.id,
        clickbaitScore: storedAnalysis.clickbaitScore,
        classification: storedAnalysis.classification,
        summary: storedAnalysis.summary,
        indicators: storedAnalysis.indicators || [],
        confidence: storedAnalysis.confidence,
        processingTime: storedAnalysis.processingTime || 0,
        title: storedAnalysis.title || undefined
      };

      res.json(response);
    } catch (error) {
      console.error("Analysis error:", error);
      res.status(500).json({ 
        message: "Internal server error during analysis" 
      });
    }
  });

  // Get recent analyses
  app.get("/api/analyses/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const analyses = await storage.getRecentAnalyses(Math.min(limit, 50));
      
      res.json(analyses.map(analysis => ({
        id: analysis.id,
        type: analysis.type,
        title: analysis.title || (analysis.content.length > 50 ? analysis.content.substring(0, 50) + '...' : analysis.content),
        clickbaitScore: analysis.clickbaitScore,
        classification: analysis.classification,
        createdAt: analysis.createdAt
      })));
    } catch (error) {
      console.error("Recent analyses error:", error);
      res.status(500).json({ 
        message: "Failed to fetch recent analyses" 
      });
    }
  });

  // Get specific analysis
  app.get("/api/analyses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          message: "Invalid analysis ID" 
        });
      }

      const analysis = await storage.getAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ 
          message: "Analysis not found" 
        });
      }

      const response: AnalyzeResponse = {
        id: analysis.id,
        clickbaitScore: analysis.clickbaitScore,
        classification: analysis.classification,
        summary: analysis.summary,
        indicators: analysis.indicators || [],
        confidence: analysis.confidence,
        processingTime: analysis.processingTime || 0,
        title: analysis.title || undefined
      };

      res.json(response);
    } catch (error) {
      console.error("Get analysis error:", error);
      res.status(500).json({ 
        message: "Failed to fetch analysis" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
