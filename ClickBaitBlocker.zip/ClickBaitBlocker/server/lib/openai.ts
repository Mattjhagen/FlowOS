import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface ClickbaitAnalysis {
  clickbaitScore: number;
  classification: string;
  summary: string;
  indicators: string[];
  confidence: number;
}

export async function analyzeClickbait(text: string, title?: string): Promise<ClickbaitAnalysis> {
  const contentToAnalyze = title ? `Title: ${title}\n\nContent: ${text}` : text;
  
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are an expert at detecting clickbait content. Analyze the given text and provide a detailed assessment.

Respond with JSON in this exact format:
{
  "clickbaitScore": number (0-100, where 100 is definitely clickbait),
  "classification": string ("Low Risk", "Medium Risk", or "High Risk"),
  "summary": string (2-3 sentence TL;DR of the actual content value),
  "indicators": array of strings (specific clickbait indicators found),
  "confidence": number (0-100, your confidence in this analysis)
}

Clickbait indicators to look for:
- Sensational language ("You won't believe", "Shocking", "Amazing")
- Numbered lists promising secrets ("10 ways", "5 secrets")
- Curiosity gaps ("What happens next will surprise you")
- Emotional manipulation
- Vague promises without specifics
- Exaggerated claims
- Question headlines designed to create urgency
- Use of superlatives without evidence`
        },
        {
          role: "user",
          content: `Please analyze this content for clickbait patterns:\n\n${contentToAnalyze}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    // Validate and sanitize the response
    return {
      clickbaitScore: Math.max(0, Math.min(100, Math.round(result.clickbaitScore || 0))),
      classification: ["Low Risk", "Medium Risk", "High Risk"].includes(result.classification) 
        ? result.classification 
        : "Medium Risk",
      summary: result.summary || "Unable to generate summary for this content.",
      indicators: Array.isArray(result.indicators) ? result.indicators : [],
      confidence: Math.max(0, Math.min(100, Math.round(result.confidence || 0)))
    };
  } catch (error) {
    throw new Error(`Failed to analyze content with AI: ${error.message}`);
  }
}
