import * as cheerio from 'cheerio';

export interface ScrapedContent {
  title: string;
  text: string;
  url: string;
}

export async function scrapeUrl(url: string): Promise<ScrapedContent> {
  try {
    // Validate URL
    const urlObj = new URL(url);
    if (!['http:', 'https:'].includes(urlObj.protocol)) {
      throw new Error('Invalid URL protocol. Only HTTP and HTTPS are supported.');
    }

    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      },
      timeout: 10000 // 10 second timeout
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch URL: ${response.status} ${response.statusText}`);
    }

    const html = await response.text();
    const $ = cheerio.load(html);

    // Extract title
    let title = $('title').text().trim();
    if (!title) {
      title = $('h1').first().text().trim();
    }
    if (!title) {
      title = $('meta[property="og:title"]').attr('content')?.trim() || '';
    }

    // Extract main content text
    let text = '';
    
    // Try to find main content areas
    const contentSelectors = [
      'article',
      '[role="main"]',
      '.main-content',
      '.post-content',
      '.entry-content',
      '.article-content',
      '.content',
      'main'
    ];

    for (const selector of contentSelectors) {
      const element = $(selector);
      if (element.length > 0) {
        text = element.text().trim();
        break;
      }
    }

    // Fallback to body if no main content found
    if (!text) {
      // Remove script, style, nav, footer, header elements
      $('script, style, nav, footer, header, .navigation, .menu, .sidebar').remove();
      text = $('body').text().trim();
    }

    // Clean up the text
    text = text
      .replace(/\s+/g, ' ') // Replace multiple spaces with single space
      .replace(/\n+/g, '\n') // Replace multiple newlines with single newline
      .trim();

    // Limit text length for analysis
    if (text.length > 5000) {
      text = text.substring(0, 5000) + '...';
    }

    if (!text || text.length < 50) {
      throw new Error('Unable to extract meaningful content from the URL. The page may be empty or require JavaScript.');
    }

    return {
      title: title || 'No title found',
      text,
      url
    };
  } catch (error) {
    if (error.message.includes('Invalid URL')) {
      throw error;
    }
    throw new Error(`Failed to scrape URL: ${error.message}`);
  }
}
