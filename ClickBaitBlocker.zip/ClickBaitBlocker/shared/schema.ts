import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const analyses = pgTable("analyses", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // "url" or "text"
  content: text("content").notNull(), // URL or direct text content
  originalText: text("original_text"), // scraped text for URLs
  title: text("title"), // article title if available
  clickbaitScore: integer("clickbait_score").notNull(), // 0-100
  classification: text("classification").notNull(), // "Low Risk", "Medium Risk", "High Risk"
  summary: text("summary").notNull(), // AI-generated TL;DR
  indicators: text("indicators").array(), // detected clickbait indicators
  confidence: integer("confidence").notNull(), // AI confidence 0-100
  processingTime: integer("processing_time"), // milliseconds
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAnalysisSchema = createInsertSchema(analyses).omit({
  id: true,
  createdAt: true,
});

export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;
export type Analysis = typeof analyses.$inferSelect;

// API request/response schemas
export const analyzeRequestSchema = z.object({
  type: z.enum(["url", "text"]),
  content: z.string().min(1, "Content is required"),
});

export type AnalyzeRequest = z.infer<typeof analyzeRequestSchema>;

export const analyzeResponseSchema = z.object({
  id: z.number(),
  clickbaitScore: z.number(),
  classification: z.string(),
  summary: z.string(),
  indicators: z.array(z.string()),
  confidence: z.number(),
  processingTime: z.number(),
  title: z.string().optional(),
});

export type AnalyzeResponse = z.infer<typeof analyzeResponseSchema>;
