import { Loader2 } from "lucide-react";

export function LoadingState() {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-8">
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-50 rounded-full mb-4">
          <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 mb-2">Analyzing Content</h3>
        <p className="text-slate-600 mb-4">Our AI is processing your content for clickbait patterns...</p>
        <div className="w-full bg-gray-200 rounded-full h-2 max-w-md mx-auto">
          <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{ width: "60%" }}></div>
        </div>
      </div>
    </div>
  );
}
