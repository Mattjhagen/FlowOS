import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { analyzeRequestSchema, type AnalyzeRequest } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Link, AlignLeft, Brain, Globe } from "lucide-react";

interface AnalysisFormProps {
  onAnalyze: (data: AnalyzeRequest) => void;
}

export function AnalysisForm({ onAnalyze }: AnalysisFormProps) {
  const [mode, setMode] = useState<"url" | "text">("url");

  const form = useForm<AnalyzeRequest>({
    resolver: zodResolver(analyzeRequestSchema),
    defaultValues: {
      type: "url",
      content: "",
    },
  });

  const watchedContent = form.watch("content");

  const handleSubmit = (data: AnalyzeRequest) => {
    onAnalyze({ ...data, type: mode });
  };

  const switchToUrlMode = () => {
    setMode("url");
    form.setValue("content", "");
    form.clearErrors();
  };

  const switchToTextMode = () => {
    setMode("text");
    form.setValue("content", "");
    form.clearErrors();
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
      <div className="mb-6">
        <div className="flex items-center space-x-4 mb-4">
          <button
            type="button"
            onClick={switchToUrlMode}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-all ${
              mode === "url"
                ? "bg-blue-50 text-blue-700 border border-blue-200"
                : "text-slate-600 hover:bg-gray-50"
            }`}
          >
            <Link className="w-4 h-4 mr-2 inline" />
            Article URL
          </button>
          <button
            type="button"
            onClick={switchToTextMode}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-all ${
              mode === "text"
                ? "bg-blue-50 text-blue-700 border border-blue-200"
                : "text-slate-600 hover:bg-gray-50"
            }`}
          >
            <AlignLeft className="w-4 h-4 mr-2 inline" />
            Direct Text
          </button>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          {mode === "url" && (
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Article URL</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type="url"
                        placeholder="https://example.com/article"
                        className="pl-10"
                      />
                      <Globe className="w-4 h-4 absolute left-3 top-3.5 text-gray-400" />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          {mode === "text" && (
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Content to Analyze</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      rows={6}
                      placeholder="Paste your article title, content, or comment here..."
                      className="resize-none"
                    />
                  </FormControl>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm text-slate-500">
                      Characters: {watchedContent?.length || 0}
                    </span>
                    <span className="text-sm text-slate-500">
                      Recommended: 50-2000 characters
                    </span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <Button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3"
            disabled={!watchedContent?.trim()}
          >
            <Brain className="w-4 h-4 mr-2" />
            Analyze Content
          </Button>
        </form>
      </Form>
    </div>
  );
}
