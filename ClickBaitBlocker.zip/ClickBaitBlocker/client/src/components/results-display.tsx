import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, Bot, ChevronDown, ChevronUp, Share, Download, RotateCcw } from "lucide-react";
import type { AnalyzeResponse } from "@shared/schema";

interface ResultsDisplayProps {
  results: AnalyzeResponse;
  onNewAnalysis: () => void;
}

export function ResultsDisplay({ results, onNewAnalysis }: ResultsDisplayProps) {
  const [showDetails, setShowDetails] = useState(false);

  const getRiskColor = (score: number) => {
    if (score >= 70) return "text-red-600";
    if (score >= 40) return "text-orange-600";
    return "text-green-600";
  };

  const getRiskBgColor = (classification: string) => {
    switch (classification) {
      case "High Risk":
        return "bg-red-100 text-red-800";
      case "Medium Risk":
        return "bg-orange-100 text-orange-800";
      case "Low Risk":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getProgressBarColor = (score: number) => {
    if (score >= 70) return "bg-red-500";
    if (score >= 40) return "bg-orange-500";
    return "bg-green-500";
  };

  const getRiskIcon = (classification: string) => {
    switch (classification) {
      case "High Risk":
        return "🚨";
      case "Medium Risk":
        return "⚠️";
      case "Low Risk":
        return "✅";
      default:
        return "❓";
    }
  };

  return (
    <div className="space-y-6">
      {/* Clickbait Score Card */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-slate-900">ClickBait Analysis</h3>
          <div className="flex items-center space-x-2">
            <Shield className="w-4 h-4 text-green-500" />
            <span className="text-sm text-slate-500">
              AI Confidence: {results.confidence}%
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Score Display */}
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-3">
              <div className="absolute inset-0 rounded-full border-8 border-gray-200"></div>
              <div 
                className={`absolute inset-0 rounded-full border-8 ${getProgressBarColor(results.clickbaitScore).replace('bg-', 'border-')}`}
                style={{
                  clipPath: `polygon(50% 50%, 50% 0%, ${50 + (results.clickbaitScore / 100) * 50}% 0%, 100% 100%, 0% 100%)`,
                  transform: "rotate(-90deg)"
                }}
              ></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className={`text-2xl font-bold ${getRiskColor(results.clickbaitScore)}`}>
                  {results.clickbaitScore}
                </span>
              </div>
            </div>
            <div className="text-sm font-medium text-slate-700">ClickBait Score</div>
            <div className="text-xs text-slate-500">out of 100</div>
          </div>

          {/* Classification */}
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-3 text-2xl">
              {getRiskIcon(results.classification)}
            </div>
            <div className="text-sm font-medium text-slate-700">{results.classification}</div>
            <div className="text-xs text-slate-500">Classification</div>
          </div>

          {/* Processing Time */}
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-3">
              <Bot className="w-6 h-6 text-blue-600" />
            </div>
            <div className="text-sm font-medium text-slate-700">
              {(results.processingTime / 1000).toFixed(1)}s
            </div>
            <div className="text-xs text-slate-500">Processing Time</div>
          </div>
        </div>

        {/* ClickBait Indicators */}
        {results.indicators && results.indicators.length > 0 && (
          <div className="mt-6 pt-6 border-t border-gray-200">
            <h4 className="text-sm font-medium text-slate-700 mb-3">Detected Indicators</h4>
            <div className="flex flex-wrap gap-2">
              {results.indicators.map((indicator, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {indicator}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* TL;DR Summary Card */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-slate-900">AI Summary (TL;DR)</h3>
          <div className="flex items-center space-x-2">
            <Bot className="w-4 h-4 text-blue-500" />
            <span className="text-sm text-slate-500">Auto-generated</span>
          </div>
        </div>
        
        <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-500">
          <p className="text-slate-700 leading-relaxed">
            {results.summary}
          </p>
        </div>

        {results.title && (
          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <div className="text-sm font-medium text-slate-700 mb-1">Analyzed Title:</div>
            <div className="text-sm text-slate-600">{results.title}</div>
          </div>
        )}
      </div>

      {/* Analysis Details */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <button 
          className="w-full flex items-center justify-between text-left"
          onClick={() => setShowDetails(!showDetails)}
        >
          <h3 className="text-lg font-semibold text-slate-900">Detailed Analysis</h3>
          {showDetails ? (
            <ChevronUp className="w-5 h-5 text-slate-400" />
          ) : (
            <ChevronDown className="w-5 h-5 text-slate-400" />
          )}
        </button>
        
        {showDetails && (
          <div className="mt-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-700">ClickBait Score</span>
                  <span className={`text-sm font-bold ${getRiskColor(results.clickbaitScore)}`}>
                    {results.clickbaitScore}/100
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${getProgressBarColor(results.clickbaitScore)}`}
                    style={{ width: `${results.clickbaitScore}%` }}
                  ></div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-700">AI Confidence</span>
                  <span className="text-sm font-bold text-blue-600">
                    {results.confidence}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${results.confidence}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <div className="text-sm text-slate-600">
                <strong>Analysis ID:</strong> {results.id}
              </div>
              <div className="text-sm text-slate-600 mt-1">
                <strong>Processing Time:</strong> {results.processingTime}ms
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Button variant="outline" className="flex-1">
          <Share className="w-4 h-4 mr-2" />
          Share Analysis
        </Button>
        <Button variant="outline" className="flex-1">
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
        <Button onClick={onNewAnalysis} className="flex-1 bg-blue-600 hover:bg-blue-700">
          <RotateCcw className="w-4 h-4 mr-2" />
          Analyze New Content
        </Button>
      </div>
    </div>
  );
}
