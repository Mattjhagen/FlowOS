import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { AnalysisForm } from "@/components/analysis-form";
import { ResultsDisplay } from "@/components/results-display";
import { LoadingState } from "@/components/loading-state";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Search, HelpCircle, Settings } from "lucide-react";
import type { AnalyzeRequest, AnalyzeResponse } from "@shared/schema";

interface RecentAnalysis {
  id: number;
  type: string;
  title: string;
  clickbaitScore: number;
  classification: string;
  createdAt: string;
}

export default function Home() {
  const [results, setResults] = useState<AnalyzeResponse | null>(null);
  const { toast } = useToast();

  // Fetch recent analyses
  const { data: recentAnalyses = [] } = useQuery<RecentAnalysis[]>({
    queryKey: ["/api/analyses/recent"],
    queryFn: async () => {
      const response = await fetch("/api/analyses/recent", {
        credentials: "include"
      });
      if (!response.ok) {
        throw new Error("Failed to fetch recent analyses");
      }
      return response.json();
    }
  });

  // Analysis mutation
  const analysisMutation = useMutation({
    mutationFn: async (data: AnalyzeRequest): Promise<AnalyzeResponse> => {
      const response = await apiRequest("POST", "/api/analyze", data);
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      // Invalidate recent analyses to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/analyses/recent"] });
      toast({
        title: "Analysis Complete",
        description: "Content has been successfully analyzed for clickbait patterns.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleAnalyze = (data: AnalyzeRequest) => {
    setResults(null);
    analysisMutation.mutate(data);
  };

  const handleNewAnalysis = () => {
    setResults(null);
  };

  const getClassificationColor = (classification: string) => {
    switch (classification) {
      case "High Risk":
        return "bg-red-100 text-red-800";
      case "Medium Risk":
        return "bg-yellow-100 text-yellow-800";
      case "Low Risk":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Search className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-slate-800">ClickBait Detector</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-slate-500">Powered by AI</span>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
            Detect ClickBait with AI
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Analyze articles and comments to identify clickbait content. Get instant AI-powered scoring and concise summaries.
          </p>
        </div>

        {/* Analysis Form */}
        <AnalysisForm onAnalyze={handleAnalyze} />

        {/* Loading State */}
        {analysisMutation.isPending && <LoadingState />}

        {/* Results Display */}
        {results && !analysisMutation.isPending && (
          <ResultsDisplay results={results} onNewAnalysis={handleNewAnalysis} />
        )}

        {/* Recent Analyses */}
        {recentAnalyses.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mt-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-900">Recent Analyses</h3>
              <button 
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/analyses/recent"] })}
              >
                Refresh
              </button>
            </div>
            
            <div className="space-y-3">
              {recentAnalyses.map((analysis) => (
                <div key={analysis.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-900 truncate">
                      {analysis.title}
                    </div>
                    <div className="text-xs text-slate-500 mt-1">
                      {formatTimeAgo(analysis.createdAt)} • Score: {analysis.clickbaitScore}/100
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getClassificationColor(analysis.classification)}`}>
                      {analysis.classification}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center">
                <Search className="w-3 h-3 text-white" />
              </div>
              <span className="text-sm text-slate-600">ClickBait Detector</span>
            </div>
            <div className="flex items-center space-x-6 text-sm text-slate-500">
              <a href="#" className="hover:text-slate-700">Privacy Policy</a>
              <a href="#" className="hover:text-slate-700">Terms of Service</a>
              <a href="#" className="hover:text-slate-700">API Docs</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
