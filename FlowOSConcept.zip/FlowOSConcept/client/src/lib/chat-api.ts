import { apiRequest } from "./queryClient";

export interface ChatMessage {
  id: number;
  sessionId: string;
  sender: "user" | "ai";
  message: string;
  timestamp: Date;
}

export interface AppComponent {
  id: number;
  name: string;
  category: string;
  size: number;
  isActive: boolean;
}

export interface UserMetrics {
  storageUsed: number;
  activeComponents: number;
  batteryImpact: "low" | "medium" | "high";
}

export const chatApi = {
  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    const res = await apiRequest("GET", `/api/chat/${sessionId}`);
    return res.json();
  },

  async sendMessage(sessionId: string, message: string): Promise<ChatMessage> {
    const res = await apiRequest("POST", "/api/chat", {
      sessionId,
      sender: "user",
      message,
    });
    return res.json();
  },

  async getComponents(): Promise<AppComponent[]> {
    const res = await apiRequest("GET", "/api/components");
    return res.json();
  },

  async getActiveComponents(sessionId: string): Promise<AppComponent[]> {
    const res = await apiRequest("GET", `/api/components/active/${sessionId}`);
    return res.json();
  },

  async toggleComponent(componentId: number, isActive: boolean): Promise<void> {
    await apiRequest("POST", `/api/components/${componentId}/toggle`, {
      isActive,
    });
  },

  async runScenario(scenario: string, sessionId: string): Promise<any> {
    const res = await apiRequest("POST", `/api/scenarios/${scenario}`, {
      sessionId,
    });
    return res.json();
  },

  async getMetrics(sessionId: string): Promise<UserMetrics> {
    const res = await apiRequest("GET", `/api/metrics/${sessionId}`);
    return res.json();
  },

  async updateMetrics(sessionId: string, metrics: Partial<UserMetrics>): Promise<UserMetrics> {
    const res = await apiRequest("POST", "/api/metrics", {
      sessionId,
      ...metrics,
    });
    return res.json();
  },
};
