import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import MobileMockup from "@/components/mobile-mockup";
import PerformanceMetrics from "@/components/performance-metrics";
import FeatureCards from "@/components/feature-cards";

export default function Home() {
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);

  const handleRunScenario = (scenario: string) => {
    console.log(`Running scenario: ${scenario}`);
  };

  return (
    <div className="bg-flow-dark text-slate-50 font-inter overflow-x-hidden">
      <Navigation />
      
      <HeroSection />

      {/* Interactive Demo Section */}
      <section id="demo" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Experience the <span className="text-flow-primary">Future</span>
            </h2>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto">
              Interact with FlowOS and see how AI transforms your mobile experience
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <MobileMockup sessionId={sessionId} />
            <PerformanceMetrics sessionId={sessionId} onRunScenario={handleRunScenario} />
          </div>
        </div>
      </section>

      {/* Features Comparison */}
      <section id="features" className="py-20 px-4 bg-flow-slate/20">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Why <span className="text-flow-accent">FlowOS</span> is Different
            </h2>
            <p className="text-lg text-slate-400 max-w-3xl mx-auto">
              See how FlowOS transforms every aspect of your mobile experience
            </p>
          </motion.div>

          <FeatureCards />

          {/* Comparison Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-flow-slate/30 rounded-2xl p-8 border border-slate-700"
          >
            <h3 className="text-2xl font-bold text-white mb-8 text-center">FlowOS vs Traditional OS</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-600">
                    <th className="text-left py-4 text-slate-300">Feature</th>
                    <th className="text-center py-4 text-flow-accent">FlowOS</th>
                    <th className="text-center py-4 text-slate-400">Traditional OS</th>
                  </tr>
                </thead>
                <tbody className="space-y-4">
                  <tr className="border-b border-slate-700">
                    <td className="py-4 text-white">App Storage</td>
                    <td className="text-center py-4">
                      <span className="bg-flow-accent/20 text-flow-accent px-3 py-1 rounded-full text-sm">Partial Downloads</span>
                    </td>
                    <td className="text-center py-4 text-slate-400">Full App Downloads</td>
                  </tr>
                  <tr className="border-b border-slate-700">
                    <td className="py-4 text-white">Interface</td>
                    <td className="text-center py-4">
                      <span className="bg-flow-primary/20 text-flow-primary px-3 py-1 rounded-full text-sm">AI Conversation</span>
                    </td>
                    <td className="text-center py-4 text-slate-400">Icon Grid</td>
                  </tr>
                  <tr className="border-b border-slate-700">
                    <td className="py-4 text-white">Resource Usage</td>
                    <td className="text-center py-4">
                      <span className="bg-flow-accent/20 text-flow-accent px-3 py-1 rounded-full text-sm">Optimized</span>
                    </td>
                    <td className="text-center py-4 text-slate-400">Standard</td>
                  </tr>
                  <tr className="border-b border-slate-700">
                    <td className="py-4 text-white">Personalization</td>
                    <td className="text-center py-4">
                      <span className="bg-flow-secondary/20 text-flow-secondary px-3 py-1 rounded-full text-sm">AI Learning</span>
                    </td>
                    <td className="text-center py-4 text-slate-400">Manual Setup</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Performance Metrics */}
      <section id="performance" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Proven <span className="text-flow-primary">Performance</span>
            </h2>
            <p className="text-lg text-slate-400 max-w-3xl mx-auto">
              Real metrics from FlowOS beta testing show dramatic improvements across all key areas
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Metrics Cards */}
            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
                className="bg-flow-slate/50 rounded-2xl p-6 border border-slate-700"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-white">Storage Efficiency</h3>
                  <i className="fas fa-hdd text-flow-accent text-xl"></i>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Traditional OS</span>
                    <span className="text-white">8.4 GB</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-3">
                    <div className="bg-slate-500 h-3 rounded-full" style={{ width: "100%" }}></div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">FlowOS</span>
                    <span className="text-flow-accent font-semibold">2.1 GB</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-3">
                    <div className="bg-flow-accent h-3 rounded-full" style={{ width: "25%" }}></div>
                  </div>
                  <p className="text-sm text-flow-accent font-semibold">75% Storage Reduction</p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true }}
                className="bg-flow-slate/50 rounded-2xl p-6 border border-slate-700"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-white">Battery Performance</h3>
                  <i className="fas fa-battery-three-quarters text-flow-primary text-xl"></i>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Average Screen Time</span>
                    <span className="text-flow-primary font-semibold">+6.2 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Background Usage</span>
                    <span className="text-flow-accent font-semibold">-60%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Charging Cycles</span>
                    <span className="text-flow-accent font-semibold">-40%</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true }}
                className="bg-flow-slate/50 rounded-2xl p-6 border border-slate-700"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-white">User Satisfaction</h3>
                  <i className="fas fa-star text-flow-warning text-xl"></i>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-flow-warning mb-2">4.8/5</div>
                  <div className="flex justify-center space-x-1 mb-2">
                    <i className="fas fa-star text-flow-warning"></i>
                    <i className="fas fa-star text-flow-warning"></i>
                    <i className="fas fa-star text-flow-warning"></i>
                    <i className="fas fa-star text-flow-warning"></i>
                    <i className="fas fa-star text-flow-warning"></i>
                  </div>
                  <p className="text-sm text-slate-400">Based on 2,847 beta users</p>
                </div>
              </motion.div>
            </div>

            {/* Performance Chart */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="bg-flow-slate/30 rounded-2xl p-8 border border-slate-700"
            >
              <h3 className="text-xl font-semibold text-white mb-6">Performance Over Time</h3>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-slate-400">App Launch Speed</span>
                    <span className="text-sm text-flow-primary">+40% faster</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div className="bg-flow-primary h-2 rounded-full animate-pulse" style={{ width: "40%" }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-slate-400">Memory Usage</span>
                    <span className="text-sm text-flow-accent">-55% reduction</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div className="bg-flow-accent h-2 rounded-full animate-pulse" style={{ width: "55%" }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-slate-400">Network Efficiency</span>
                    <span className="text-sm text-flow-secondary">+65% improvement</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div className="bg-flow-secondary h-2 rounded-full animate-pulse" style={{ width: "65%" }}></div>
                  </div>
                </div>

                <div className="mt-8 p-4 bg-flow-primary/10 rounded-lg border border-flow-primary/20">
                  <p className="text-sm text-slate-300">
                    <i className="fas fa-info-circle text-flow-primary mr-2"></i>
                    Performance improvements are measured against baseline Android and iOS systems
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4 bg-gradient-to-r from-flow-primary/10 via-flow-secondary/10 to-flow-accent/10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">
              Ready to Experience the Future?
            </h2>
            <p className="text-lg text-slate-400 mb-8 max-w-2xl mx-auto">
              Join the FlowOS beta program and be among the first to experience the next generation of mobile computing.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="gradient-primary px-8 py-4 rounded-full text-white font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-300 transform hover:scale-105">
                Join Beta Program
              </button>
              <button className="border border-flow-primary text-flow-primary px-8 py-4 rounded-full font-semibold hover:bg-flow-primary hover:text-white transition-all duration-300">
                Download Whitepaper
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-slate-700">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-wave-square text-white text-sm"></i>
              </div>
              <span className="text-xl font-bold">Project Aquarius</span>
            </div>
            <div className="text-slate-400 text-sm">
              © 2024 FlowOS. All rights reserved. | Proof of Concept
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
