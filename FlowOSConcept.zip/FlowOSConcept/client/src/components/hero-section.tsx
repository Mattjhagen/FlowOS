import { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function HeroSection() {
  const [counters, setCounters] = useState({
    storage: 0,
    performance: 0,
    battery: 0,
    satisfaction: 0,
  });

  const targets = {
    storage: 75,
    performance: 40,
    battery: 60,
    satisfaction: 90,
  };

  useEffect(() => {
    const duration = 2000;
    const interval = 50;
    const steps = duration / interval;
    
    const timer = setInterval(() => {
      setCounters(prev => ({
        storage: Math.min(prev.storage + targets.storage / steps, targets.storage),
        performance: Math.min(prev.performance + targets.performance / steps, targets.performance),
        battery: Math.min(prev.battery + targets.battery / steps, targets.battery),
        satisfaction: Math.min(prev.satisfaction + targets.satisfaction / steps, targets.satisfaction),
      }));
    }, interval);

    setTimeout(() => clearInterval(timer), duration);
    return () => clearInterval(timer);
  }, []);

  const scrollToDemo = () => {
    const element = document.getElementById("demo");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="min-h-screen flex items-center justify-center pt-20 pb-10 px-4">
      <div className="max-w-6xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6 gradient-text">
            Project Aquarius
          </h1>
          <h2 className="text-2xl md:text-4xl font-light mb-6 text-slate-300">
            The Future of Mobile Operating Systems
          </h2>
          <p className="text-lg md:text-xl text-slate-400 max-w-3xl mx-auto leading-relaxed">
            FlowOS revolutionizes mobile interaction through AI-driven partial app downloads, 
            delivering only the features you need, when you need them.
          </p>
        </motion.div>

        {/* Hero Stats */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
        >
          <div className="bg-flow-slate/50 rounded-xl p-4 backdrop-blur-sm border border-slate-700">
            <div className="text-2xl font-bold text-flow-accent">
              {Math.round(counters.storage)}%
            </div>
            <div className="text-sm text-slate-400">Less Storage</div>
          </div>
          <div className="bg-flow-slate/50 rounded-xl p-4 backdrop-blur-sm border border-slate-700">
            <div className="text-2xl font-bold text-flow-primary">
              {Math.round(counters.performance)}%
            </div>
            <div className="text-sm text-slate-400">Faster Launch</div>
          </div>
          <div className="bg-flow-slate/50 rounded-xl p-4 backdrop-blur-sm border border-slate-700">
            <div className="text-2xl font-bold text-flow-secondary">
              {Math.round(counters.battery)}%
            </div>
            <div className="text-sm text-slate-400">Better Battery</div>
          </div>
          <div className="bg-flow-slate/50 rounded-xl p-4 backdrop-blur-sm border border-slate-700">
            <div className="text-2xl font-bold text-flow-warning">
              {Math.round(counters.satisfaction)}%
            </div>
            <div className="text-sm text-slate-400">User Satisfaction</div>
          </div>
        </motion.div>

        <motion.button
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          onClick={scrollToDemo}
          className="gradient-primary px-8 py-4 rounded-full text-white font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-300 transform hover:scale-105"
        >
          Experience FlowOS
          <i className="fas fa-arrow-down ml-2"></i>
        </motion.button>
      </div>
    </section>
  );
}
