import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { chatApi, type UserMetrics } from "@/lib/chat-api";

interface PerformanceMetricsProps {
  sessionId: string;
  onRunScenario: (scenario: string) => void;
}

export default function PerformanceMetrics({ sessionId, onRunScenario }: PerformanceMetricsProps) {
  const queryClient = useQueryClient();

  const { data: metrics } = useQuery({
    queryKey: [`/api/metrics/${sessionId}`],
    queryFn: () => chatApi.getMetrics(sessionId),
    refetchInterval: 3000,
  });

  const runScenarioMutation = useMutation({
    mutationFn: (scenario: string) => chatApi.runScenario(scenario, sessionId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/metrics/${sessionId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/chat/${sessionId}`] });
    },
  });

  const handleScenario = (scenario: string) => {
    runScenarioMutation.mutate(scenario);
    onRunScenario(scenario);
  };

  const getStoragePercentage = () => {
    if (!metrics) return 25;
    return Math.min((metrics.storageUsed / 8400) * 100, 100);
  };

  const getBatteryColor = (impact: string) => {
    switch (impact) {
      case "low": return "text-flow-accent";
      case "medium": return "text-flow-warning";
      case "high": return "text-red-500";
      default: return "text-flow-accent";
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-2xl font-bold mb-4 text-white">Interactive Demo</h3>
        <p className="text-slate-400 mb-6">Try different scenarios to see how FlowOS adapts to your needs</p>
      </div>

      {/* Scenario Buttons */}
      <div className="space-y-4">
        <button
          onClick={() => handleScenario("productivity")}
          disabled={runScenarioMutation.isPending}
          className="w-full bg-flow-slate/50 border border-slate-600 rounded-lg p-4 text-left hover:border-flow-primary transition-colors group disabled:opacity-50"
        >
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-white font-semibold group-hover:text-flow-primary">Productivity Mode</h4>
              <p className="text-sm text-slate-400">AI loads work apps and schedules</p>
            </div>
            <i className="fas fa-briefcase text-flow-primary"></i>
          </div>
        </button>

        <button
          onClick={() => handleScenario("entertainment")}
          disabled={runScenarioMutation.isPending}
          className="w-full bg-flow-slate/50 border border-slate-600 rounded-lg p-4 text-left hover:border-flow-secondary transition-colors group disabled:opacity-50"
        >
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-white font-semibold group-hover:text-flow-secondary">Entertainment Mode</h4>
              <p className="text-sm text-slate-400">Load gaming and media features</p>
            </div>
            <i className="fas fa-gamepad text-flow-secondary"></i>
          </div>
        </button>

        <button
          onClick={() => handleScenario("fitness")}
          disabled={runScenarioMutation.isPending}
          className="w-full bg-flow-slate/50 border border-slate-600 rounded-lg p-4 text-left hover:border-flow-accent transition-colors group disabled:opacity-50"
        >
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-white font-semibold group-hover:text-flow-accent">Fitness Mode</h4>
              <p className="text-sm text-slate-400">Health tracking and workout apps</p>
            </div>
            <i className="fas fa-running text-flow-accent"></i>
          </div>
        </button>
      </div>

      {/* Real-time Metrics */}
      <div className="bg-flow-slate/30 rounded-lg p-6 border border-slate-700">
        <h4 className="text-white font-semibold mb-4">Real-time Performance</h4>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-400">Storage Used</span>
            <span className="text-sm text-white">
              {metrics ? `${(metrics.storageUsed / 1000).toFixed(1)} GB` : "2.1 GB"}
            </span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-2">
            <div 
              className="bg-flow-accent h-2 rounded-full transition-all duration-500"
              style={{ width: `${getStoragePercentage()}%` }}
            ></div>
          </div>
          
          <div className="flex justify-between items-center mt-3">
            <span className="text-sm text-slate-400">Active Components</span>
            <span className="text-sm text-white">
              {metrics ? `${metrics.activeComponents}/32` : "8/32"}
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-400">Battery Impact</span>
            <span className={`text-sm font-semibold ${getBatteryColor(metrics?.batteryImpact || "low")}`}>
              {metrics?.batteryImpact ? metrics.batteryImpact.charAt(0).toUpperCase() + metrics.batteryImpact.slice(1) : "Low"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
