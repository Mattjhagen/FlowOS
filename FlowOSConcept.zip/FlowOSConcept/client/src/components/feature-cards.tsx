import { motion } from "framer-motion";

export default function FeatureCards() {
  const features = [
    {
      icon: "fas fa-download",
      title: "Partial App Downloads",
      description: "Only download the features you actually use. Save storage and bandwidth with intelligent component loading.",
      color: "flow-primary",
      delay: 0,
    },
    {
      icon: "fas fa-brain",
      title: "AI-Driven Interface",
      description: "Interact naturally with your device through conversation. No more hunting through app icons and menus.",
      color: "flow-secondary",
      delay: 0.1,
    },
    {
      icon: "fas fa-chart-line",
      title: "Predictive Loading",
      description: "AI learns your patterns and preloads features before you need them, creating seamless experiences.",
      color: "flow-accent",
      delay: 0.2,
    },
    {
      icon: "fas fa-battery-three-quarters",
      title: "Extended Battery Life",
      description: "Reduced background activity and optimized resource usage leads to significantly better battery performance.",
      color: "flow-warning",
      delay: 0.3,
    },
    {
      icon: "fas fa-tachometer-alt",
      title: "Faster Performance",
      description: "With less bloat and smarter resource management, your device runs faster and more efficiently.",
      color: "flow-primary",
      delay: 0.4,
    },
    {
      icon: "fas fa-user-cog",
      title: "Personalized Experience",
      description: "Your device adapts to your unique usage patterns, becoming more helpful and intuitive over time.",
      color: "flow-secondary",
      delay: 0.5,
    },
  ];

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
      {features.map((feature, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: feature.delay }}
          viewport={{ once: true }}
          className={`bg-flow-slate/50 rounded-2xl p-6 border border-slate-700 hover:border-${feature.color} transition-colors group`}
        >
          <div className={`w-12 h-12 bg-${feature.color}/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-${feature.color}/30 transition-colors`}>
            <i className={`${feature.icon} text-${feature.color} text-xl`}></i>
          </div>
          <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
          <p className="text-slate-400 mb-4">{feature.description}</p>
          <div className={`flex items-center text-sm text-${feature.color}`}>
            <span>Learn more</span>
            <i className="fas fa-arrow-right ml-2"></i>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
