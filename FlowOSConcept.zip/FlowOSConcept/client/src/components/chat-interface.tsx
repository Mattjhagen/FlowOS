import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { chatApi, type ChatMessage } from "@/lib/chat-api";

interface ChatInterfaceProps {
  sessionId: string;
}

export default function ChatInterface({ sessionId }: ChatInterfaceProps) {
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  const { data: messages = [], isLoading } = useQuery({
    queryKey: [`/api/chat/${sessionId}`],
    queryFn: () => chatApi.getChatMessages(sessionId),
    refetchInterval: 2000, // Poll for new messages
  });

  const sendMessageMutation = useMutation({
    mutationFn: (message: string) => chatApi.sendMessage(sessionId, message),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/chat/${sessionId}`] });
      setIsTyping(true);
      
      // Stop typing indicator after 3 seconds
      setTimeout(() => setIsTyping(false), 3000);
    },
  });

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    // Initialize speech recognition
    if (typeof window !== 'undefined' && (window as any).webkitSpeechRecognition) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onstart = () => {
        setIsListening(true);
      };

      recognitionInstance.onresult = (event: any) => {
        const transcript = event.results[event.results.length - 1][0].transcript;
        setInputMessage(transcript);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, []);

  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      sendMessageMutation.mutate(inputMessage);
      setInputMessage("");
    }
  };

  const handleQuickAction = (message: string) => {
    sendMessageMutation.mutate(message);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  const startListening = () => {
    if (recognition) {
      recognition.start();
    }
  };

  const stopListening = () => {
    if (recognition) {
      recognition.stop();
    }
  };

  if (isLoading) {
    return (
      <div className="px-6 py-4 h-full flex items-center justify-center">
        <div className="animate-pulse text-slate-400">Loading chat...</div>
      </div>
    );
  }

  return (
    <div className="px-6 py-4 h-full flex flex-col">
      {/* AI Assistant Header */}
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 gradient-primary rounded-full flex items-center justify-center">
          <i className="fas fa-brain text-white text-sm"></i>
        </div>
        <div>
          <h3 className="text-white font-semibold">Flow Assistant</h3>
          <p className="text-xs text-slate-400">AI-Powered Interface</p>
        </div>
      </div>

      {/* Chat Messages */}
      <div
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto space-y-4 scrollbar-hide"
        style={{ maxHeight: "300px" }}
      >
        {messages.length === 0 && (
          <div className="flex space-x-3">
            <div className="w-8 h-8 bg-flow-primary rounded-full flex items-center justify-center flex-shrink-0 relative">
              <i className="fas fa-robot text-white text-xs"></i>
              <div className="absolute -top-1 -right-1">
                <i className="fas fa-sparkles text-flow-accent text-xs animate-sparkle opacity-30"></i>
              </div>
            </div>
            <div className="bg-flow-slate rounded-lg p-3 max-w-xs relative">
              <div className="absolute -top-1 right-2">
                <i className="fas fa-star text-flow-accent text-xs animate-sparkle-delayed opacity-20"></i>
              </div>
              <p className="text-sm text-white">
                Hello! I'm your FlowOS AI assistant. I can help you with Facebook, X, Reddit, making calls, managing contacts, and much more. Try speaking to me by holding the microphone button!
              </p>
            </div>
          </div>
        )}

        {messages.map((message) => (
          <div
            key={message.id}
            className={message.sender === "ai" ? "flex space-x-3" : "flex justify-end"}
          >
            {message.sender === "ai" && (
              <div className="w-8 h-8 bg-flow-primary rounded-full flex items-center justify-center flex-shrink-0 relative">
                <i className="fas fa-robot text-white text-xs"></i>
                {/* Subtle sparkles for AI messages */}
                <div className="absolute -top-1 -right-1">
                  <i className="fas fa-sparkles text-flow-accent text-xs animate-sparkle opacity-30"></i>
                </div>
              </div>
            )}
            <div
              className={`rounded-lg p-3 max-w-xs relative ${
                message.sender === "ai"
                  ? "bg-flow-slate text-white"
                  : "bg-flow-primary text-white"
              }`}
            >
              {/* Add sparkle to AI message bubbles */}
              {message.sender === "ai" && (
                <div className="absolute -top-1 right-2">
                  <i className="fas fa-star text-flow-accent text-xs animate-sparkle-delayed opacity-20"></i>
                </div>
              )}
              <p className="text-sm">{message.message}</p>
            </div>
          </div>
        ))}

        {/* Typing Indicator with Sparkles */}
        {isTyping && (
          <div className="flex space-x-3">
            <div className="w-8 h-8 bg-flow-primary rounded-full flex items-center justify-center flex-shrink-0 relative">
              <i className="fas fa-robot text-white text-xs"></i>
              {/* Sparkle effects around AI avatar */}
              <div className="absolute -top-1 -right-1">
                <i className="fas fa-sparkles text-flow-accent text-xs animate-sparkle"></i>
              </div>
              <div className="absolute -bottom-1 -left-1">
                <i className="fas fa-star text-flow-warning text-xs animate-sparkle-delayed"></i>
              </div>
              <div className="absolute top-0 left-0">
                <i className="fas fa-plus text-flow-secondary text-xs animate-sparkle-delayed-2"></i>
              </div>
            </div>
            <div className="bg-flow-slate rounded-lg p-3 max-w-xs relative">
              {/* Sparkles floating around the message bubble */}
              <div className="absolute -top-2 right-2">
                <i className="fas fa-sparkles text-flow-primary text-xs animate-sparkle opacity-60"></i>
              </div>
              <div className="absolute -bottom-2 left-4">
                <i className="fas fa-star text-flow-accent text-xs animate-sparkle-delayed opacity-40"></i>
              </div>
              <div className="absolute top-1 -right-3">
                <i className="fas fa-plus text-flow-warning text-xs animate-sparkle-delayed-2 opacity-50"></i>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-flow-accent rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-flow-accent rounded-full animate-pulse" style={{ animationDelay: "0.2s" }}></div>
                <div className="w-2 h-2 bg-flow-accent rounded-full animate-pulse" style={{ animationDelay: "0.4s" }}></div>
                <span className="text-xs text-slate-300 ml-2">AI thinking...</span>
                <i className="fas fa-brain text-flow-primary text-xs animate-pulse ml-1"></i>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="mt-4 grid grid-cols-3 gap-2">
        <button
          onClick={() => handleQuickAction("Open Facebook and show my news feed")}
          className="bg-flow-slate/50 rounded-lg p-2 text-center border border-slate-600 hover:border-blue-500 transition-colors"
        >
          <i className="fab fa-facebook text-blue-500 mb-1"></i>
          <p className="text-xs text-white">Facebook</p>
        </button>
        <button
          onClick={() => handleQuickAction("Open X and show trending posts")}
          className="bg-flow-slate/50 rounded-lg p-2 text-center border border-slate-600 hover:border-gray-400 transition-colors"
        >
          <i className="fab fa-x-twitter text-gray-400 mb-1"></i>
          <p className="text-xs text-white">X</p>
        </button>
        <button
          onClick={() => handleQuickAction("Show my contacts")}
          className="bg-flow-slate/50 rounded-lg p-2 text-center border border-slate-600 hover:border-flow-accent transition-colors"
        >
          <i className="fas fa-address-book text-flow-accent mb-1"></i>
          <p className="text-xs text-white">Contacts</p>
        </button>
        <button
          onClick={() => handleQuickAction("Open Reddit and show popular posts")}
          className="bg-flow-slate/50 rounded-lg p-2 text-center border border-slate-600 hover:border-orange-500 transition-colors"
        >
          <i className="fab fa-reddit text-orange-500 mb-1"></i>
          <p className="text-xs text-white">Reddit</p>
        </button>
        <button
          onClick={() => handleQuickAction("Show my recent calls")}
          className="bg-flow-slate/50 rounded-lg p-2 text-center border border-slate-600 hover:border-flow-primary transition-colors"
        >
          <i className="fas fa-phone text-flow-primary mb-1"></i>
          <p className="text-xs text-white">Calls</p>
        </button>
        <button
          onClick={() => handleQuickAction("Open camera to take a photo")}
          className="bg-flow-slate/50 rounded-lg p-2 text-center border border-slate-600 hover:border-flow-secondary transition-colors"
        >
          <i className="fas fa-camera text-flow-secondary mb-1"></i>
          <p className="text-xs text-white">Camera</p>
        </button>
      </div>

      {/* Input Area */}
      <div className="mt-4 flex items-center space-x-3">
        <div className="flex-1 bg-flow-slate rounded-full px-4 py-2 border border-slate-600">
          <input
            type="text"
            placeholder="Ask Flow anything or hold to speak..."
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="w-full bg-transparent text-white text-sm outline-none placeholder-slate-400"
          />
        </div>
        <button
          onMouseDown={startListening}
          onMouseUp={stopListening}
          onTouchStart={startListening}
          onTouchEnd={stopListening}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 relative ${
            isListening 
              ? 'bg-red-500 shadow-lg shadow-red-500/50 scale-110' 
              : 'bg-flow-accent hover:bg-flow-accent/80'
          }`}
        >
          {isListening ? (
            <>
              <i className="fas fa-microphone text-white text-sm animate-pulse"></i>
              {/* Listening indicator with sparkles */}
              <div className="absolute inset-0 rounded-full border-2 border-red-300 animate-ping"></div>
              <div className="absolute -top-1 -right-1">
                <i className="fas fa-sparkles text-red-300 text-xs animate-sparkle"></i>
              </div>
              <div className="absolute -bottom-1 -left-1">
                <i className="fas fa-star text-red-200 text-xs animate-sparkle-delayed"></i>
              </div>
            </>
          ) : (
            <i className="fas fa-microphone text-white text-sm"></i>
          )}
        </button>
        <button
          onClick={handleSendMessage}
          disabled={sendMessageMutation.isPending}
          className="w-10 h-10 bg-flow-primary rounded-full flex items-center justify-center hover:bg-flow-primary/80 transition-colors disabled:opacity-50"
        >
          <i className="fas fa-paper-plane text-white text-sm"></i>
        </button>
      </div>
    </div>
  );
}
