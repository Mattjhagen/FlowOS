import { motion } from "framer-motion";
import ChatInterface from "./chat-interface";

interface MobileMockupProps {
  sessionId: string;
}

export default function MobileMockup({ sessionId }: MobileMockupProps) {
  return (
    <div className="flex justify-center relative">
      {/* Phone Frame */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="relative"
      >
        <div className="w-80 h-[640px] bg-black rounded-[3rem] p-2 shadow-2xl">
          <div className="w-full h-full bg-flow-dark rounded-[2.5rem] overflow-hidden relative">
            {/* Status Bar */}
            <div className="flex justify-between items-center px-6 py-2 text-white text-sm">
              <span>9:41</span>
              <div className="flex space-x-1 text-xs">
                <i className="fas fa-signal"></i>
                <i className="fas fa-wifi"></i>
                <i className="fas fa-battery-three-quarters"></i>
              </div>
            </div>

            {/* FlowOS Interface */}
            <ChatInterface sessionId={sessionId} />
          </div>
        </div>

        {/* Floating Elements */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="absolute -right-8 top-20 animate-float"
        >
          <div className="bg-flow-accent rounded-lg p-2 text-black text-xs font-semibold shadow-lg">
            75% Storage Saved
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 1.3 }}
          className="absolute -left-8 top-40 animate-float"
          style={{ animationDelay: "1s" }}
        >
          <div className="bg-flow-primary rounded-lg p-2 text-white text-xs font-semibold shadow-lg">
            AI Learning Active
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
