import { useState, useEffect } from "react";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      className={`fixed top-0 w-full z-50 border-b transition-all duration-300 ${
        isScrolled
          ? "bg-flow-dark/90 backdrop-blur-lg border-slate-800"
          : "bg-flow-dark/80 backdrop-blur-lg border-slate-800"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
              <i className="fas fa-wave-square text-white text-sm"></i>
            </div>
            <span className="text-xl font-bold text-white">FlowOS</span>
            <span className="text-xs bg-flow-accent px-2 py-1 rounded-full text-black font-semibold">
              BETA
            </span>
          </div>
          
          <div className="hidden md:flex space-x-6">
            <button
              onClick={() => scrollToSection("demo")}
              className="text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Demo
            </button>
            <button
              onClick={() => scrollToSection("features")}
              className="text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Features
            </button>
            <button
              onClick={() => scrollToSection("performance")}
              className="text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Performance
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button className="text-slate-300 hover:text-white">
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
