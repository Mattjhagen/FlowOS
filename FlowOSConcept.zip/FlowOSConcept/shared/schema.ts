import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  sender: text("sender").notNull(), // 'user' or 'ai'
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const appComponents = pgTable("app_components", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  size: integer("size").notNull(), // in MB
  isActive: boolean("is_active").default(false),
});

export const userMetrics = pgTable("user_metrics", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  storageUsed: integer("storage_used").notNull(), // in MB
  activeComponents: integer("active_components").notNull(),
  batteryImpact: text("battery_impact").notNull(), // 'low', 'medium', 'high'
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  sessionId: true,
  sender: true,
  message: true,
});

export const insertAppComponentSchema = createInsertSchema(appComponents).pick({
  name: true,
  category: true,
  size: true,
  isActive: true,
});

export const insertUserMetricsSchema = createInsertSchema(userMetrics).pick({
  sessionId: true,
  storageUsed: true,
  activeComponents: true,
  batteryImpact: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type AppComponent = typeof appComponents.$inferSelect;
export type InsertAppComponent = z.infer<typeof insertAppComponentSchema>;
export type UserMetrics = typeof userMetrics.$inferSelect;
export type InsertUserMetrics = z.infer<typeof insertUserMetricsSchema>;

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  chatMessages: many(chatMessages),
  userMetrics: many(userMetrics),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  user: one(users, {
    fields: [chatMessages.sessionId],
    references: [users.username],
  }),
}));

export const userMetricsRelations = relations(userMetrics, ({ one }) => ({
  user: one(users, {
    fields: [userMetrics.sessionId],
    references: [users.username],
  }),
}));
