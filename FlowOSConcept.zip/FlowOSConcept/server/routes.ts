import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatMessageSchema, insertUserMetricsSchema } from "@shared/schema";
import { generateAIResponse } from "./openai";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoints
  app.get("/api/chat/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessages(sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(validatedData);
      
      // Generate AI response for user messages using OpenAI
      if (validatedData.sender === "user") {
        setTimeout(async () => {
          try {
            const components = await storage.getAppComponents();
            const metrics = await storage.getUserMetrics(validatedData.sessionId);
            
            const context = {
              userMessage: validatedData.message,
              sessionId: validatedData.sessionId,
              availableApps: components.map(c => c.name),
              currentMetrics: {
                storageUsed: metrics?.storageUsed || 2100,
                activeComponents: metrics?.activeComponents || 8,
                batteryImpact: metrics?.batteryImpact || "low"
              }
            };

            const aiResponse = await generateAIResponse(context);
            
            await storage.createChatMessage({
              sessionId: validatedData.sessionId,
              sender: "ai",
              message: aiResponse
            });
          } catch (error) {
            console.error("AI response generation failed:", error);
            // Fallback to basic response if OpenAI fails
            await storage.createChatMessage({
              sessionId: validatedData.sessionId,
              sender: "ai",
              message: "I'm processing your request. FlowOS is optimizing the experience for you..."
            });
          }
        }, 1500);
      }
      
      res.json(message);
    } catch (error) {
      res.status(400).json({ error: "Invalid chat message data" });
    }
  });

  // App components endpoints
  app.get("/api/components", async (req, res) => {
    try {
      const components = await storage.getAppComponents();
      res.json(components);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch components" });
    }
  });

  app.get("/api/components/active/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const activeComponents = await storage.getActiveComponents(sessionId);
      res.json(activeComponents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch active components" });
    }
  });

  app.post("/api/components/:id/toggle", async (req, res) => {
    try {
      const componentId = parseInt(req.params.id);
      const { isActive } = req.body;
      
      await storage.updateComponentStatus(componentId, isActive);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: "Failed to update component status" });
    }
  });

  // Scenario simulation endpoint
  app.post("/api/scenarios/:scenario", async (req, res) => {
    try {
      const { scenario } = req.params;
      const { sessionId } = req.body;
      
      const scenarios = {
        productivity: {
          components: ["Calendar Sync", "Email Client"],
          storageUsed: 2800,
          activeComponents: 12,
          batteryImpact: "medium" as const,
          message: "Switching to productivity mode. Loading calendar, email, and document editing features..."
        },
        entertainment: {
          components: ["Gaming Engine", "Media Streaming"],
          storageUsed: 3200,
          activeComponents: 15,
          batteryImpact: "high" as const,
          message: "Entertainment mode activated! Loading gaming engine and media streaming components..."
        },
        fitness: {
          components: ["Health Sensors", "Workout Tracking"],
          storageUsed: 1900,
          activeComponents: 6,
          batteryImpact: "low" as const,
          message: "Fitness mode ready! Loading health sensors and workout tracking features..."
        }
      };

      const selectedScenario = scenarios[scenario as keyof typeof scenarios];
      if (!selectedScenario) {
        return res.status(400).json({ error: "Invalid scenario" });
      }

      // Update metrics
      await storage.updateUserMetrics({
        sessionId,
        storageUsed: selectedScenario.storageUsed,
        activeComponents: selectedScenario.activeComponents,
        batteryImpact: selectedScenario.batteryImpact
      });

      // Add AI message
      await storage.createChatMessage({
        sessionId,
        sender: "ai",
        message: selectedScenario.message
      });

      res.json(selectedScenario);
    } catch (error) {
      res.status(500).json({ error: "Failed to run scenario" });
    }
  });

  // Metrics endpoints
  app.get("/api/metrics/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const metrics = await storage.getUserMetrics(sessionId);
      
      // Return default metrics if none exist
      if (!metrics) {
        const defaultMetrics = {
          storageUsed: 2100,
          activeComponents: 8,
          batteryImpact: "low" as const
        };
        await storage.updateUserMetrics({
          sessionId,
          ...defaultMetrics
        });
        return res.json(defaultMetrics);
      }
      
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch metrics" });
    }
  });

  app.post("/api/metrics", async (req, res) => {
    try {
      const validatedData = insertUserMetricsSchema.parse(req.body);
      const metrics = await storage.updateUserMetrics(validatedData);
      res.json(metrics);
    } catch (error) {
      res.status(400).json({ error: "Invalid metrics data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
