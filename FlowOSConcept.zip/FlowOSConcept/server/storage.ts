import { 
  users, 
  chatMessages, 
  appComponents, 
  userMetrics,
  type User, 
  type InsertUser,
  type ChatMessage,
  type InsertChatMessage,
  type AppComponent,
  type InsertAppComponent,
  type UserMetrics,
  type InsertUserMetrics
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Chat functionality
  getChatMessages(sessionId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // App components
  getAppComponents(): Promise<AppComponent[]>;
  getActiveComponents(sessionId: string): Promise<AppComponent[]>;
  updateComponentStatus(componentId: number, isActive: boolean): Promise<void>;
  
  // User metrics
  getUserMetrics(sessionId: string): Promise<UserMetrics | undefined>;
  updateUserMetrics(metrics: InsertUserMetrics): Promise<UserMetrics>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    const messages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.sessionId, sessionId))
      .orderBy(chatMessages.timestamp);
    return messages;
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db
      .insert(chatMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getAppComponents(): Promise<AppComponent[]> {
    const components = await db.select().from(appComponents);
    return components;
  }

  async getActiveComponents(sessionId: string): Promise<AppComponent[]> {
    const components = await db
      .select()
      .from(appComponents)
      .where(eq(appComponents.isActive, true));
    return components;
  }

  async updateComponentStatus(componentId: number, isActive: boolean): Promise<void> {
    await db
      .update(appComponents)
      .set({ isActive })
      .where(eq(appComponents.id, componentId));
  }

  async getUserMetrics(sessionId: string): Promise<UserMetrics | undefined> {
    const [metrics] = await db
      .select()
      .from(userMetrics)
      .where(eq(userMetrics.sessionId, sessionId))
      .orderBy(userMetrics.timestamp)
      .limit(1);
    return metrics || undefined;
  }

  async updateUserMetrics(insertMetrics: InsertUserMetrics): Promise<UserMetrics> {
    const [metrics] = await db
      .insert(userMetrics)
      .values(insertMetrics)
      .returning();
    return metrics;
  }
}

export const storage = new DatabaseStorage();
