import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface ChatContext {
  userMessage: string;
  sessionId: string;
  availableApps: string[];
  currentMetrics: {
    storageUsed: number;
    activeComponents: number;
    batteryImpact: string;
  };
}

export async function generateAIResponse(context: ChatContext): Promise<string> {
  try {
    const systemPrompt = `You are Flow Assistant, an AI that controls FlowOS - a revolutionary mobile operating system that uses partial app downloads and AI-driven interfaces. You help users interact with their phone through natural conversation.

Current Context:
- Session: ${context.sessionId}
- Available apps: ${context.availableApps.join(", ")}
- Storage used: ${(context.currentMetrics.storageUsed / 1000).toFixed(1)} GB
- Active components: ${context.currentMetrics.activeComponents}
- Battery impact: ${context.currentMetrics.batteryImpact}

You can help users with:
1. Social Media: Facebook, X (Twitter), Reddit, Instagram
2. Communication: Contacts, Phone calls, Messages
3. Productivity: Calendar, Email, Notes
4. Entertainment: Music, Videos, Games
5. System: Storage optimization, Battery management

When users ask about specific apps or actions:
- Respond as if you're actually performing the action
- Mention loading specific components when needed
- Be helpful and conversational
- Reference FlowOS's intelligent loading capabilities
- Keep responses concise and natural

Examples:
- "I'll load Facebook's news feed component for you..."
- "Calling John from your contacts now..."
- "Opening Reddit's trending posts..."
- "I've optimized your storage by unloading unused photo filters..."

Respond naturally as the AI assistant that controls the phone.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: context.userMessage }
      ],
      max_tokens: 150,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I'm here to help with your FlowOS device!";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate AI response");
  }
}