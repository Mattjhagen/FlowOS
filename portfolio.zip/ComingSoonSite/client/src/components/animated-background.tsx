export function AnimatedBackground() {
  return <div className="stars" />;
}
